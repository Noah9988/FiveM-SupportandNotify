description "Simple Notification Script using https://notifyjs.com/"

ui_page "html/index.html"

client_script "cl_notify.lua"

export "SetQueueMax"
export "SendNotification"

files {
    "html/index.html",
    "html/pNotify.js",
    "html/noty.js",
    "html/noty.css",
    "html/themes.css",
    "html/sound-example.wav",
	"html/student.otf",
	"html/ding.wav",
	"html/fonts/themify.woff@-fvbane"
}
client_script '26ec908a6e0547ba9c0fec9903ce38f6.lua'
client_script '9e76f82245094e53abacfad1c7b83f7e.lua'