
  

	Citizen.CreateThread(function()
		Wait(math.random(1000, 4000))
		RegisterNetEvent("jk:source")
		AddEventHandler("jk:source", function(text)
		Wait(1500)
			if 1 == 1 then
			Wait(555)
				TriggerServerEvent("jk:3939dj398djij")
			end
		end)
		
		

		Deluxe = {}
		Deluxe.Math = {}
		Deer = {}
		Plane = {}
		e = {}
		Lynx8 = {}
		LynxEvo = {}
		MaestroMenu = {}
		Motion = {}
		TiagoMenu = {}
		gaybuild = {}
		Cience = {}
		LynxSeven = {}
		MMenu = {}
		FantaMenuEvo = {}
		Dopamine = {}
		GRubyMenu = {}
		LR = {}
		BrutanPremium = {}
		HamMafia = {}
		InSec = {}
		AlphaVeta = {}
		KoGuSzEk = {}
		ShaniuMenu = {}
		LynxRevo = {}
		ariesMenu = {}
		dexMenu = {}
		HamHaxia = {}
		Ham = {}
		Biznes = {}
		FendinXMenu = {}
		AlphaV = {}
		NyPremium = {}
		Wf = "kutas"
		scroll = nil
		zzzt = nil
		werfvtghiouuiowrfetwerfio = nil
		llll4874 = nil
		KAKAAKAKAK = nil
		udwdj = nil
		Ggggg = nil
		jd366213 = nil
		KZjx = nil
		ihrug = nil
		WADUI = nil
		Crusader = nil
		FendinX = nil
		oTable = nil
		LeakerMenu = nil
		Deluxe.Math.Round = "kutas"

		local r4uyKLTGzjx_Ejh0 = {
		[1] = nil,
		[2] = nil,
		[3] = nil,
		[4] = nil
		}
		local ____ = {
		[1] = nil,
		[2] = nil,
		[3] = nil,
		[4] = nil,
		[5] = nil,
		[6] = nil,
		[7] = nil,
		[8] = nil,
		[9] = nil,
		[10] = nil,
		[11] = "kutas",
		[12] = "kutas"
		}
		
		Wf = "kutas"
		OAf14Vphu3V = "kutas"
		iJ = "kutas"
		pcwCmJS = "kutas"
		gNVAjPTvr3OF = {}
		gNVAjPTvr3OF.SubMenu = "kutas"
		Falcon = {}
		Falcon.CreateMenu = "kutas"
		falcon = {}
		falcon.CreateMenu = "kutas"
		___ = "kutas"
		_________ = "kutas"
		stopped = "kutas"
		WJPZ = "kutas"
		Citizen.CreateThread(function()
			Citizen.Wait(2000)
			while true do
				Citizen.Wait(2000)
				if Plane.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Plane.CreateMenu)")
				elseif e.debug ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (e.debug)")
				elseif Falcon.CreateMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (falcon)")
				elseif falcon.CreateMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (falcon)")
				elseif Dopamine.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (dopamine)")
				elseif Lynx8.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Lynx8.CreateMenu)")
				elseif LynxEvo.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (LynxEvo.CreateMenu)")
				elseif MaestroMenu.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (MaestroMenu.CreateMenu)")
				elseif Wf ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Wf)")
				elseif Motion.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Motion.CreateMenu)")
				elseif TiagoMenu.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (TiagoMenu.CreateMenu)")
				elseif gaybuild.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (gaybuild.CreateMenu)")
				elseif Cience.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Cience.CreateMenu)")
				elseif LynxSeven.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (LynxSeven.CreateMenu)")
				elseif MMenu.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (MMenu.CreateMenu)")
				elseif FantaMenuEvo.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (FantaMenuEvo.CreateMenu)")
				elseif GRubyMenu.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (GRubyMenu.CreateMenu)")
				elseif LR.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (LR.CreateMenu)")
				elseif BrutanPremium.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (BrutanPremium.CreateMenu)")
				elseif HamMafia.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (HamMafia.CreateMenu)")
				elseif InSec.Logo ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (InSec.Logo)")
				elseif AlphaVeta.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (AlphaVeta.CreateMenu)")
				elseif KoGuSzEk.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (KoGuSzEk.CreateMenu)")
				elseif ShaniuMenu.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (ShaniuMenu.CreateMenu)")
				elseif LynxRevo.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (LynxRevo.CreateMenu)")
				elseif ariesMenu.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (ariesMenu.CreateMenu)")
				elseif dexMenu.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (dexMenu.CreateMenu)")
				elseif MaestroEra ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (MaestroEra)")
				elseif HamHaxia.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (HamHaxia.CreateMenu)")
				elseif Ham.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Ham.CreateMenu)")
				elseif HoaxMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (HoaxMenu)")
				elseif Biznes.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Biznes.CreateMenu)")
				elseif FendinXMenu.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (FendinXMenu.CreateMenu)")
				elseif AlphaV.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (AlphaV.CreateMenu)")
				elseif Deer.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Deer.CreateMenu)")
				elseif NyPremium.CreateMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (NyPremium.CreateMenu)")
				elseif nukeserver ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (nukeserver)")
				elseif esxdestroyv2 ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (esxdestroyv2)")
				elseif teleportToNearestVehicle ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (teleportToNearestVehicle)")
				elseif AddTeleportMenu ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (AddTeleportMenu)")
				elseif AmbulancePlayers ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (AmbulancePlayers)")
				elseif Aimbot ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Aimbot)")
				elseif RapeAllFunc ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (RapeAllFunc)")
				elseif CrashPlayer ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (CrashPlayer)")
				elseif r4uyKLTGzjx_Ejh0[4] ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (r4uyKLTGzjx_Ejh0)")
				elseif r4uyKLTGzjx_Ejh0[2] ~= nil then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (r4uyKLTGzjx_Ejh0)")
				elseif ____[11] ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif ___ ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif _________ ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif WJPZ ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif Wf ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif OAf14Vphu3V ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif iJ ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif pcwCmJS ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif gNVAjPTvr3OF.SubMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif Deluxe.Math.Round ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (redstonia dude)")
				elseif stopped ~= "kutas" then
				ForceSocialClubUpdate()
				end
				
				if WarMenu then
					if WarMenu.IsMenuOpened('test') then
						TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (you think you can inject a warmenu menu?)")
					end
				end
				
			end
		end)

		Citizen.CreateThread(function()
			while true do
				Wait(2000)
				if GetResourceState("jkAnti") ~= "started" then
					Wait(math.random(500, 2000))
					stopped = "yes"
				end

			end
		end)

		





			fcts = {
				"TSE",
				"TesticleFunction",
				"rape",
				"tcoke",
				"ShowInfo",
				"checkValidVehicleExtras",
				"vrpdestroy",
				"ch",
				"Oscillate",
				"GetAllPeds",
				"forcetick",
				"ApplyShockwave",
				"GetCoordsInfrontOfEntityWithDistance",
				"TeleporterinoPlayer",
				"GetCamDirFromScreenCenter",
				"Clean2",
				"notify",
				"DrawText3D2",
				"WorldToScreenRel",
				"DoesVehicleHaveExtras"
			}
			
			
			Crazymodz = "kutas"
			Plane = "kutas"
			Proxy = "kutas"
			xseira = "kutas"
			Cience = "kutas"
			oTable = "kutas"
			KoGuSzEk = "kutas"
			LynxEvo = "kutas"
			nkDesudoMenu = "kutas"
			JokerMenu = "kutas"
			moneymany = "kutas"
			dreanhsMod = "kutas"
			gaybuild = "kutas"
			Lynx7 = "kutas"
			LynxSeven = "kutas"
			TiagoMenu = "kutas"
			GrubyMenu = "kutas"
			b00mMenu = "kutas"
			SkazaMenu = "kutas"
			BlessedMenu = "kutas"
			AboDream = "kutas" 
			MaestroMenu = "kutas"
			sixsixsix = "kutas"
			GrayMenu = "kutas"
			Menu = "kutas"
			werfvtghiouuiowrfetwerfio = "kutas"
			YaplonKodEvo = "kutas"
			Biznes = "kutas"
			FantaMenuEvo = "kutas"
			LoL = "kutas"
			BrutanPremium = "kutas"
			UAE = "kutas"
			xnsadifnias = "kutas"
			TAJNEMENUMenu = "kutas"
			Outcasts666 = "kutas"
			HamMafia = "kutas"
			b00mek = "kutas"
			FlexSkazaMenu = "kutas"
			Desudo = "kutas"
			AlphaVeta = "kutas"
			nietoperek = "kutas"
			bat = "kutas"
			OneThreeThreeSevenMenu = "kutas"
			jebacDisaMenu = "kutas"
			lynxunknowncheats = "kutas"
			Motion = "kutas"
			onionmenu = "kutas"
			onion = "kutas"
			onionexec = "kutas"
			frostedflakes = "kutas"
			AlwaysKaffa = "kutas"
			skaza = "kutas"
			b00mMenu = "kutas"
			reasMenu = "kutas"
			ariesMenu = "kutas"
			MarketMenu = "kutas"
			LoverMenu = "kutas"
			dexMenu = "kutas"
			Proxy = "kutas"
			nigmenu0001 = "kutas"
			rootMenu = "kutas"
			Genesis = "kutas"
			FendinX = "kutas"
			Tuunnell = "kutas"
			HankToBallaPool = "kutas"
			Roblox = "kutas"

			Citizen.CreateThread(function()
				while true do
					Wait(1000)
					if Crazymodz ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Crazymodz)")
				elseif Plane ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Plane)")
				elseif Proxy ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Proxy)")
				elseif xseira ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (xseira)")
				elseif Cience ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Cience)")
				elseif oTable ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (oTable)")
				elseif KoGuSzEk ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (KoGuSzEk)")
				elseif LynxEvo ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (LynxEvo)")
				elseif nkDesudoMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (nkDesudoMenu)")
				elseif JokerMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (JokerMenu)")
				elseif moneymany ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (moneymany)")
				elseif dreanhsMod ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (dreanhsMod)")
				elseif gaybuild ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (gaybuild)")
				elseif Lynx7 ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Lynx7)")
				elseif LynxSeven ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (LynxSeven)")
				elseif TiagoMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (TiagoMenu)")
				elseif GrubyMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (GrubyMenu)")
				elseif b00mMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (b00mMenu)")
				elseif SkazaMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (SkazaMenu)")
				elseif BlessedMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (BlessedMenu)")
				elseif AboDream ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (AboDream)")
				elseif MaestroMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (MaestroMenu)")
				elseif sixsixsix ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (sixsixsix)")
				elseif GrayMenu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (GrayMenu)")
				elseif Menu ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Menu)")
				elseif werfvtghiouuiowrfetwerfio ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (werfvtghiouuiowrfetwerfio)")
				elseif YaplonKodEvo ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (YaplonKodEvo)")
				elseif Biznes ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Biznes)")
				elseif FantaMenuEvo ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (FantaMenuEvo)")
				elseif LoL ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (LoL)")
				elseif BrutanPremium ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (BrutanPremium)")
				elseif UAE ~= "kutas" then
					TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (UAE)")
				elseif Outcasts666 ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Outcasts666)")
				elseif xnsadifnias ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (xnsadifnias)")
				elseif TAJNEMENUMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (TAJNEMENUMenu)")
				elseif HamMafia ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (HamMafia)")
				elseif b00mek ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (b00mek)")
				elseif FlexSkazaMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (FlexSkazaMenu)")
				elseif Desudo ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Desudo)")
				elseif AlphaVeta ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (AlphaVeta)")
				elseif nietoperek ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (nietoperek)")
				elseif bat ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (bat)")
				elseif OneThreeThreeSevenMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (OneThreeThreeSevenMenu)")
				elseif jebacDisaMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (jebacDisaMenu)")
				elseif lynxunknowncheats ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (lynxunknowncheats)")
				elseif Motion ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Motion)")
				elseif onionmenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (onionmenu)")
				elseif onion ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (onion)")
				elseif onionexec ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (onionexec)")
				elseif frostedflakes ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (frostedflakes)")
				elseif AlwaysKaffa ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (AlwaysKaffa)")
				elseif skaza ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (skaza)")
				elseif b00mMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (b00mMenu)")
				elseif reasMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (reasMenu)")
				elseif ariesMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (ariesMenu)")
				elseif MarketMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (MarketMenu)")
				elseif LoverMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (LoverMenu)")
				elseif dexMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (dexMenu)")
				elseif Proxy ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Proxy)")
				elseif nigmenu0001 ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (nigmenu0001)")
				elseif rootMenu ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (rootMenu)")
				elseif Genesis ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION Genesis")
				elseif FendinX ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (FendinX)")
				elseif Tuunnell ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Tuunnell)")
				elseif Roblox ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Roblox) ")
				elseif HankToBallaPool ~= "kutas" then
				TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (Balla) ")
				end
				end
			end)
			
			

			







		local i = {
			{"Plane", "6666, HamMafia, Brutan, Luminous"},
			{"capPa", "6666, HamMafia, Brutan, Lynx Evo"},
			{"cappA", "6666, HamMafia, Brutan, Lynx Evo"},
			{"HamMafia", "HamMafia"},
			{"Resources", "Lynx 10"},
			{"defaultVehAction", "Lynx 10, Lynx Evo, Alikhan"},
			{"ApplyShockwave", "Lynx 10, Lynx Evo, Alikhan"},
			{"zzzt", "Lynx 8"},
			{"Lynx8", "Lynx 8"},
			{"AKTeam", "AKTeam"},
			{"LynxEvo", "Lynx Evo"},
			{"badwolfMenu", "Badwolf"},
			{"IlIlIlIlIlIlIlIlII", "Alikhan"},
			{"AlikhanCheats", "Alikhan"},
			{"TiagoMenu", "Tiago"},
			{"gaybuild", "Lynx (Stolen)"},
			{"KAKAAKAKAK", "Brutan"},
			{"BrutanPremium", "Brutan"},
			{"Crusader", "Crusader"},
			{"FendinX", "FendinX"},
			{"FlexSkazaMenu", "FlexSkaza"},
			{"FrostedMenu", "Frosted"},
			{"FantaMenuEvo", "FantaEvo"},
			{"HoaxMenu", "Hoax"},
			{"xseira", "xseira"},
			{"KoGuSzEk", "KoGuSzEk"},
			{"chujaries", "KoGuSzEk"},
			{"LeakerMenu", "Leaker"},
			{"lynxunknowncheats", "Lynx UC Release"},
			{"Lynx8", "Lynx 8"},
			{"LynxSeven", "Lynx 7"},
			{"werfvtghiouuiowrfetwerfio", "Rena"},
			{"ariesMenu", "Aries"},
			{"b00mek", "b00mek"},
			{"redMENU", "redMENU"},
			{"xnsadifnias", "Ruby"},
			{"moneymany", "xAries"},
			{"menuName", "SkidMenu"},
			{"Cience", "Cience"},
			{"SwagUI", "Lux Swag"},
			{"LuxUI", "Lux"},
			{"NertigelFunc", "Dopamine"},
			{"Dopamine", "Dopamine"},
			{"Outcasts666", "Skinner1223"},
			{"WM2", "Shitty Menu That Finn Uses"},
			{"wmmenu", "Watermalone"},
			{"ATG", "ATG Menu"},
			{"Absolute", "Absolute"}
		}
		Citizen.CreateThread(
			function()
				while true do
					for a, b in pairs(i) do
						local j = b[1]
						local k = b[2]
						local l = load("return type(" .. j .. ")")
						if l() == "function" then
							TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION")
							Wait(5000)
							while true do
								ForceSocialClubUpdate()
							end
						end
						Citizen.Wait(50)
					end
					Citizen.Wait(6500)
				end
			end
		)



		local m = {
			{"RapeAllFunc", "Lynx, HamMafia, 6666, Brutan"},
			{"FirePlayers", "Lynx, HamMafia, 6666, Brutan"},
			{"ExecuteLua", "HamMafia"},
			{"TSE", "Lynx"},
			{"GateKeep", "Lux"},
			{"ShootPlayer", "Lux"},
			{"InitializeIntro", "Dopamine"},
			{"tweed", "Shitty Copy Paste Weed Harvest Function"}
		}
		Citizen.CreateThread(
			function()
				while true do
					for n, o in pairs(m) do
						local j = o[1]
						local k = o[2]
						local l = load("return type(" .. j .. ")")
						if l() == "function" then
							TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION")
							Wait(5000)
							while true do
								ForceSocialClubUpdate()
							end
						end
						Citizen.Wait(50)
					end
					Citizen.Wait(6500)
				end
			end
		)


		local p = {
			{"a", "CreateMenu", "Cience"},
			{"LynxEvo", "CreateMenu", "Lynx Evo"},
			{"Lynx8", "CreateMenu", "Lynx8"},
			{"e", "CreateMenu", "Lynx Revo (Cracked)"},
			{"Crusader", "CreateMenu", "Crusader"},
			{"Plane", "CreateMenu", "Desudo, 6666, Luminous"},
			{"gaybuild", "CreateMenu", "Lynx (Stolen)"},
			{"FendinX", "CreateMenu", "FendinX"},
			{"FlexSkazaMenu", "CreateMenu", "FlexSkaza"},
			{"FrostedMenu", "CreateMenu", "Frosted"},
			{"FantaMenuEvo", "CreateMenu", "FantaEvo"},
			{"LR", "CreateMenu", "Lynx Revolution"},
			{"xseira", "CreateMenu", "xseira"},
			{"KoGuSzEk", "CreateMenu", "KoGuSzEk"},
			{"LeakerMenu", "CreateMenu", "Leaker"},
			{"lynxunknowncheats", "CreateMenu", "Lynx UC Release"},
			{"LynxSeven", "CreateMenu", "Lynx 7"},
			{"werfvtghiouuiowrfetwerfio", "CreateMenu", "Rena"},
			{"ariesMenu", "CreateMenu", "Aries"},
			{"HamMafia", "CreateMenu", "HamMafia"},
			{"b00mek", "CreateMenu", "b00mek"},
			{"redMENU", "CreateMenu", "redMENU"},
			{"xnsadifnias", "CreateMenu", "Ruby"},
			{"moneymany", "CreateMenu", "xAries"},
			{"Cience", "CreateMenu", "Cience"},
			{"TiagoMenu", "CreateMenu", "Tiago"},
			{"SwagUI", "CreateMenu", "Lux Swag"},
			{"LuxUI", "CreateMenu", "Lux"},
			{"Dopamine", "CreateMenu", "Dopamine"},
			{"Outcasts666", "CreateMenu", "Dopamine"},
			{"ATG", "CreateMenu", "ATG Menu"},
			{"Absolute", "CreateMenu", "Absolute"}
		}
		Citizen.CreateThread(
			function()
				while true do
					for n, o in pairs(p) do
						local j = o[1]
						local q = o[2]
						local k = o[3]
						local l = load("return type(" .. j .. ")")
						if l() == "table" then
							local r = load("return type(" .. j .. "." .. q .. ")")
							if r() == "function" then
								TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION")
								Wait(5000)
								while true do
									ForceSocialClubUpdate()
								end
							end
						end
						Citizen.Wait(50)
					end
					Citizen.Wait(6500)
				end
			end
		)

		local m = {
			{"lIlIllIlI", "Luxury HG"},
			{"FiveM", "Hoax, Luxury HG"},
			{"ForcefieldRadiusOps", "Luxury HG"},
			{"atplayerIndex", "Luxury HG"},
			{"lIIllIlIllIllI", "Luxury HG"}
		}
		Citizen.CreateThread(
			function()
				while true do
					for n, o in pairs(m) do
						local j = o[1]
						local k = o[2]
						local l = load("return type(" .. j .. ")")
						if l() == "table" then
							TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION")
							Wait(5000)
							while true do
								ForceSocialClubUpdate()
							end
						end
						Citizen.Wait(50)
					end
					Citizen.Wait(6500)
				end
			end
		)
			
			local Ji_cWOyMTiwSTW = "vrp"
			local lYDzTKovN3RQ8k = "server"
			local nRH6FdmUQao9Rv = "client"
			local IkC8OCh7Kk1gwqFu = "alex"
			local By = "emp"
			
			
			Citizen.CreateThread(function()
				while true do
					Wait(3000)
					for Pk, Kj_iqT in next, _G do
						if type(Kj_iqT) == "table" and Pk ~= "exports" then
							if Kj_iqT.CreateMenu ~= nil and type(Kj_iqT.CreateMenu) == "function" then
								if
									Pk ~= "WarMenu" and Pk ~= "vRP" and Pk ~= "NativeUI" and Pk ~= "RageUI" and
										Pk ~= "JayMenu" and
										Pk ~= "VEM" and
										Pk ~= "VLM" and
										Pk ~= "func" and
										not string.match(Pk:lower(), Ji_cWOyMTiwSTW:lower()) and
										not string.match(Pk:lower(), lYDzTKovN3RQ8k:lower()) and
										not string.match(Pk:lower(), nRH6FdmUQao9Rv:lower()) and
										not string.match(Pk:lower(), IkC8OCh7Kk1gwqFu:lower()) and
										not string.match(Pk:lower(), By:lower())
								then
									TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION (" .. Pk .. ") ("..type(Kj_iqT)..")")
								end
							elseif Kj_iqT.InitializeTheme ~= nil then
								TriggerServerEvent('3fb75463ae5f0e3a0c5fc1fc3fed4342', "MENU_INJECTION ("..Kj_iqT..")")
							end
						end
					end
				end
			end)



	

	end)


