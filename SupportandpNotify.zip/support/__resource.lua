--[[

  Made with love by Cheleber, you can join my RP Server here: www.grandtheftlusitan.com

--]]

description 'Reply and Report command'

version '1.0.0'

client_script {

  'client.lua'

}

server_scripts {

  'server.lua',
  '@mysql-async/lib/MySQL.lua'

}
